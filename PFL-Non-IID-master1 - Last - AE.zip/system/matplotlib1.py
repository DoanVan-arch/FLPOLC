import matplotlib.pyplot as plt
import numpy as np

# Read data from the file
file_path = 'test_metrics_results.txt'
algorithms = []
datasets = []
train_losses = []
test_accuracies = []
std_test_accuracies = []
test_aucs = []
std_test_aucs = []

with open(file_path, 'r') as file:
    lines = file.readlines()
    for line in lines:
        if "Algorithm" in line:
            parts = line.split(", ")
            algorithms.append(parts[0].split(": ")[1])
            datasets.append(parts[1].split(": ")[1])
        elif "Averaged Train Loss" in line:
            train_losses.append(float(line.split(": ")[1]))
        elif "Averaged Test Accuracy" in line:
            test_accuracies.append(float(line.split(": ")[1]))
        elif "Std Test Accuracy" in line:
            std_test_accuracies.append(float(line.split(": ")[1]))
        elif "Averaged Test AUC" in line:
            test_aucs.append(float(line.split(": ")[1]))
        elif "Std Test AUC" in line:
            std_test_aucs.append(float(line.split(": ")[1]))

# Convert lists to numpy arrays
test_accuracies = np.array(test_accuracies)
std_test_accuracies = np.array(std_test_accuracies)

# Plot the data
x = np.arange(len(test_accuracies))

plt.figure(figsize=(12, 6))
plt.plot(x, test_accuracies, color='blue', label='Averaged Test Accuracy')
plt.fill_between(x, test_accuracies - std_test_accuracies, test_accuracies + std_test_accuracies, color='blue', alpha=0.2)
plt.xlabel('Iteration')
plt.ylabel('Accuracy')
plt.title('Averaged Test Accuracy with Std Deviation')
plt.legend()
plt.grid(True)
plt.savefig('test_accuracy_plot.png')
plt.show()
