import copy
import torch
import torch.nn as nn
import numpy as np
import os
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sklearn.preprocessing import label_binarize
from sklearn import metrics
from utils.data_utils import read_client_data


class Client(object):
    """
    Base class for clients in federated learning.
    """

    def __init__(self, args, id, train_samples, test_samples, **kwargs):
        self.model = copy.deepcopy(args.model)
        self.algorithm = args.algorithm
        self.dataset = args.dataset
        self.device = args.device
        self.id = id  # integer
        self.save_folder_name = args.save_folder_name

        self.num_classes = args.num_classes
        self.train_samples = train_samples
        self.test_samples = test_samples
        self.batch_size = args.batch_size
        self.learning_rate = args.local_learning_rate
        self.local_epochs = args.local_epochs

        # check BatchNorm
        self.has_BatchNorm = False
        for layer in self.model.children():
            if isinstance(layer, nn.BatchNorm2d):
                self.has_BatchNorm = True
                break

        self.train_slow = kwargs['train_slow']
        self.send_slow = kwargs['send_slow']
        self.train_time_cost = {'num_rounds': 0, 'total_cost': 0.0}
        self.send_time_cost = {'num_rounds': 0, 'total_cost': 0.0}

        self.privacy = args.privacy
        self.dp_sigma = args.dp_sigma

        self.loss = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.SGD(self.model.parameters(), lr=self.learning_rate)
        self.learning_rate_scheduler = torch.optim.lr_scheduler.ExponentialLR(
            optimizer=self.optimizer, 
            gamma=args.learning_rate_decay_gamma
        )
        self.learning_rate_decay = args.learning_rate_decay


    def load_train_data(self, batch_size=None):
        if batch_size == None:
            batch_size = self.batch_size
        train_data = read_client_data(self.dataset, self.id, is_train=True)
        return DataLoader(train_data, batch_size, drop_last=True, shuffle=True)

    def load_test_data(self, batch_size=None):
        if batch_size == None:
            batch_size = self.batch_size
        test_data = read_client_data(self.dataset, self.id, is_train=False)
        return DataLoader(test_data, batch_size, drop_last=False, shuffle=True)
        
    def set_parameters(self, model):
        for new_param, old_param in zip(model.parameters(), self.model.parameters()):
            old_param.data = new_param.data.clone()

    def clone_model(self, model, target):
        for param, target_param in zip(model.parameters(), target.parameters()):
            target_param.data = param.data.clone()
            # target_param.grad = param.grad.clone()

    def update_parameters(self, model, new_params):
        for param, new_param in zip(model.parameters(), new_params):
            param.data = new_param.data.clone()
    def test_metrics(self, model=None):
        testloader = self.load_test_data()
        trainloader = self.load_train_data()
        # pdb.set_trace()
        if model == None:
            model = self.model
        model.eval()

        test_acc = 0
        test_num = 0
        y_prob = []
        y_true = []
        y_predict = []
        y_gt = []
        train_labels = set()

        # Thu thập nhãn từ tập dữ liệu huấn luyện
        with torch.no_grad():
            for x, y in trainloader:
                train_labels.update(y.cpu().numpy())
        with torch.no_grad():
            for x, y in testloader:
                if type(x) == type([]):
                    x[0] = x[0].to(self.device)
                else:
                    x = x.to(self.device)
                y = y.to(self.device)
                # pdb.set_trace()
                output = model(x)
                
              #  test_acc += (torch.sum(torch.argmax(output, dim=1) == y)).item()
                test_num += y.shape[0]

                y_predict.extend(torch.argmax(output, dim=1).detach().cpu().numpy())
                y_gt.extend(y.detach().cpu().numpy())

                nc = self.num_classes
               
        y_true = label_binarize(np.array(y_gt), classes=np.arange(nc))
        y_prob = label_binarize(np.array (y_predict), classes=np.arange(nc))
        f1 = metrics.f1_score (y_true, y_prob, average='micro')
        auc = metrics.roc_auc_score(y_true, y_prob, average='micro')
        acc = metrics.accuracy_score(y_true, y_prob)
        label_accuracy = {}
        for label in range(nc):
            y_true_label = y_true[:, label]
            y_prob_label = y_prob[:, label]
            label_acc = metrics.accuracy_score(y_true_label, y_prob_label)
            label_accuracy[label] = label_acc

        # In ra độ chính xác của từng nhãn
         # Chia kết quả thành hai phần
        matched_labels = {label: acc for label, acc in label_accuracy.items() if label in train_labels}
        unmatched_labels = {label: acc for label, acc in label_accuracy.items() if label not in train_labels}

        # In ra độ chính xác của từng nhãn
      #  print("Matched Labels Accuracy:")
       ## for label, acc in matched_labels.items():
         #   print(f"Accuracy for label {label}: {acc:.2f}")
        
        #print("Unmatched Labels Accuracy:")
        #for label, acc in unmatched_labels.items():
           # print(f"Accuracy for label {label}: {acc:.2f}")

         # Ghi kết quả vào file text không ghi đè
        with open("test_metrics_result_client"+str(self.id)+".txt", "a") as f:
            f.write("Label accuracies:\n")
            f.write("Matched Label Accuracies:\n")
            for label, acc in matched_labels.items():
                f.write(f"Accuracy for label {label}: {acc:.2f}\n")
            
            f.write("Unmatched Label Accuracies:\n")
            for label, acc in unmatched_labels.items():
                f.write(f"Accuracy for label {label}: {acc:.2f}\n")
            f.write(f"\nOverall accuracy: {acc:.2f}\n")
           # f.write(f"F1 score: {f1:.2f}\n")
            f.write(f"AUC: {auc:.2f}\n")
            f.write("-" * 40 + "\n")
        return acc, f1, auc, y_gt, y_predict, test_num
    def test_metrics_old(self):
        testloaderfull = self.load_test_data()
        # self.model = self.load_model('model')
        # self.model.to(self.device)
        self.model.eval()

        test_acc = 0
        test_num = 0
        y_prob = []
        y_true = []
        
        with torch.no_grad():
            for x, y in testloaderfull:
                if type(x) == type([]):
                    x[0] = x[0].to(self.device)
                else:
                    x = x.to(self.device)
                y = y.to(self.device)
                output = self.model(x)

                test_acc += (torch.sum(torch.argmax(output, dim=1) == y)).item()
                test_num += y.shape[0]

                y_prob.append(output.detach().cpu().numpy())
                nc = self.num_classes
                if self.num_classes == 2:
                    nc += 1
                lb = label_binarize(y.detach().cpu().numpy(), classes=np.arange(nc))
                if self.num_classes == 2:
                    lb = lb[:, :2]
                y_true.append(lb)

        # self.model.cpu()
        # self.save_model(self.model, 'model')

        y_prob = np.concatenate(y_prob, axis=0)
        y_true = np.concatenate(y_true, axis=0)

        auc = metrics.roc_auc_score(y_true, y_prob, average='micro')
        
        return test_acc, test_num, auc

    def train_metrics(self):
        trainloader = self.load_train_data()
        # self.model = self.load_model('model')
        # self.model.to(self.device)
        self.model.eval()

        train_num = 0
        losses = 0
        with torch.no_grad():
            for x, y in trainloader:
                if type(x) == type([]):
                    x[0] = x[0].to(self.device)
                else:
                    x = x.to(self.device)
                y = y.to(self.device)
                output = self.model(x)
                loss = self.loss(output, y)
                train_num += y.shape[0]
                losses += loss.item() * y.shape[0]

        # self.model.cpu()
        # self.save_model(self.model, 'model')

        return losses, train_num

    # def get_next_train_batch(self):
    #     try:
    #         # Samples a new batch for persionalizing
    #         (x, y) = next(self.iter_trainloader)
    #     except StopIteration:
    #         # restart the generator if the previous generator is exhausted.
    #         self.iter_trainloader = iter(self.trainloader)
    #         (x, y) = next(self.iter_trainloader)

    #     if type(x) == type([]):
    #         x = x[0]
    #     x = x.to(self.device)
    #     y = y.to(self.device)

    #     return x, y


    def save_item(self, item, item_name, item_path=None):
        if item_path == None:
            item_path = self.save_folder_name
        if not os.path.exists(item_path):
            os.makedirs(item_path)
        torch.save(item, os.path.join(item_path, "client_" + str(self.id) + "_" + item_name + ".pt"))

    def load_item(self, item_name, item_path=None):
        if item_path == None:
            item_path = self.save_folder_name
        return torch.load(os.path.join(item_path, "client_" + str(self.id) + "_" + item_name + ".pt"))

    # @staticmethod
    # def model_exists():
    #     return os.path.exists(os.path.join("models", "server" + ".pt"))
