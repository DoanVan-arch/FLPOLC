import copy
import torch
import torch.nn as nn
import numpy as np
import time
import torch.nn.functional as F
from flcore.clients.clientbase import Client
from flcore.optimizers.fedoptimizer import PerAvgOptimizer
class SmoothLossTracker:
    def __init__(self, lambda_smooth=0.1, history_size=3):
        """
        Khởi tạo SmoothLossTracker.
        Args:
            lambda_smooth (float): Tham số điều chỉnh độ mịn.
            history_size (int): Số lượng loss gần nhất để theo dõi (n do người dùng nhập).
        """
        self.lambda_smooth = lambda_smooth  # Tham số điều chỉnh độ mịn
        self.history_size = history_size    # Số lượng loss gần nhất (n)
        self.loss_history = []              # Lưu trữ các giá trị loss gần nhất

    def compute_variation(self):
        """Tính độ biến thiên tương đối giữa các loss gần nhất."""
        if len(self.loss_history) < 2:
            return 0.0  # Nếu không đủ loss để tính, trả về 0

        variations = []
        for i in range(1, len(self.loss_history)):
            L_t = self.loss_history[i]
            L_t_minus_1 = self.loss_history[i - 1]
            # Tính độ biến thiên tương đối theo công thức
            delta_L = torch.abs(L_t - L_t_minus_1) / (L_t_minus_1 + 1e-8)  # Thêm epsilon để tránh chia cho 0
            variations.append(delta_L)

        # Trả về trung bình của các độ biến thiên
        return torch.mean(torch.stack(variations))
    def adjust_loss(self, current_loss):
        """
        Điều chỉnh loss hiện tại dựa trên độ biến thiên của các loss gần nhất.
        Args:
            current_loss (torch.Tensor): Giá trị loss hiện tại.
        Returns:
            torch.Tensor: Loss đã được điều chỉnh.
        """
        # Thêm loss hiện tại vào history
        self.loss_history.append(current_loss.detach())
        if len(self.loss_history) > self.history_size:
            self.loss_history.pop(0)

        # Tính độ biến thiên
        variation = self.compute_variation()

        # Điều chỉnh loss dựa trên độ biến thiên
        adjusted_loss = current_loss * (1 + self.lambda_smooth * variation)

        return adjusted_loss
    def moreau_envelope_smooth(self, current_loss):
        """Áp dụng Moreau Envelope để làm mịn loss."""
        # Thêm loss hiện tại vào history
        self.loss_history.append(current_loss.detach())
        if len(self.loss_history) > self.history_size:
            self.loss_history.pop(0)

        # Tính độ biến thiên
        variation = self.compute_variation()

        # Điều chỉnh lambda_smooth dựa trên độ biến thiên
        adaptive_lambda = self.lambda_smooth * (1 + variation)

        # Áp dụng Moreau Envelope
        if len(self.loss_history) > 0:
            loss_tensor = torch.stack(self.loss_history)
            # Tính trung bình có trọng số của các loss gần nhất
            weights = torch.exp(-torch.arange(len(loss_tensor), dtype=torch.float32) / adaptive_lambda)
            weights = weights / weights.sum()
            smoothed_loss = (current_loss + 
                           adaptive_lambda * torch.sum(weights * loss_tensor)) / (1 + adaptive_lambda)
        else:
            smoothed_loss = current_loss

        return smoothed_loss
class clientPer(Client):
    def __init__(self, args, id, train_samples, test_samples, **kwargs):
        super().__init__(args, id, train_samples, test_samples, **kwargs)
        self.beta = self.learning_rate
        self.tau = args.tau
        self.mu = args.mu

        self.global_model = None
        self.old_model = copy.deepcopy(self.model)
        self.lamda = args.lamda
        self.K = args.K
        self.personalized_learning_rate = args.p_learning_rate
        self.beta = self.learning_rate
        self.optimizer = PerAvgOptimizer(self.model.parameters(), lr=self.learning_rate)
        self.learning_rate_scheduler = torch.optim.lr_scheduler.ExponentialLR(
            optimizer=self.optimizer, 
            gamma=args.learning_rate_decay_gamma
        )
    def train(self):
        trainloader = self.load_train_data()
        
        start_time = time.time()

        # self.model.to(self.device)
        self.model.train()

        max_local_epochs = self.local_epochs
        if self.train_slow:
            max_local_epochs = np.random.randint(1, max_local_epochs // 2)

        for step in range(max_local_epochs):
            smooth_tracker = SmoothLossTracker(lambda_smooth=0.1, history_size=3)
            for i, (x, y) in enumerate(trainloader):
                if type(x) == type([]):
                    x[0] = x[0].to(self.device)
                else:
                    x = x.to(self.device)
                y = y.to(self.device)
                if self.train_slow:
                    time.sleep(0.1 * np.abs(np.random.rand()))
                output = self.model(x)
                rep = self.model.base(x)
                output = self.model.head(rep)
                loss = self.loss(output, y)
              
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                
                if type(x) == type([]):
                    x[0] = x[0].to(self.device)
                else:
                    x = x.to(self.device)
                y = y.to(self.device)
                if self.train_slow:
                    time.sleep(0.1 * np.abs(np.random.rand()))
                output = self.model(x)
                rep = self.model.base(x)
                output = self.model.head(rep)
                loss = self.loss(output, y)
                rep_old = self.old_model.base(x).detach()
                rep_global = self.global_model.base(x).detach()
                loss_con = - torch.log(torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) / 
                    (torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) + torch.exp(F.cosine_similarity(rep, rep_old) / self.tau)))
                loss += self.mu * torch.mean(loss_con)
                loss = smooth_tracker.moreau_envelope_smooth(loss)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

        # self.model.cpu()

        if self.learning_rate_decay:
            self.learning_rate_scheduler.step()

        self.train_time_cost['num_rounds'] += 1
        self.train_time_cost['total_cost'] += time.time() - start_time

    def set_parameters(self, model):
        for new_param, old_param in zip(model.parameters(), self.model.base.parameters()):
            old_param.data = new_param.data.clone()
        self.global_model = model
