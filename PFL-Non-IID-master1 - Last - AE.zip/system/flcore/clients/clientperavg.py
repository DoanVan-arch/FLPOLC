import numpy as np
import torch
import time
import copy
import torch.nn as nn
import torch.nn.functional as F
from flcore.optimizers.fedoptimizer import PerAvgOptimizer
from flcore.clients.clientbase import Client
from utils.data_utils import read_client_data
from torch.utils.data import DataLoader
from sklearn.preprocessing import StandardScaler, LabelEncoder

class SmoothLossTracker:
    def __init__(self, lambda_smooth=0.1, history_size=3):
        """
        Khởi tạo SmoothLossTracker.
        Args:
            lambda_smooth (float): Tham số điều chỉnh độ mịn.
            history_size (int): Số lượng loss gần nhất để theo dõi (n do người dùng nhập).
        """
        self.lambda_smooth = lambda_smooth  # Tham số điều chỉnh độ mịn
        self.history_size = history_size    # Số lượng loss gần nhất (n)
        self.loss_history = []              # Lưu trữ các giá trị loss gần nhất

    def compute_variation(self):
        """Tính độ biến thiên tương đối giữa các loss gần nhất."""
        if len(self.loss_history) < 2:
            return 0.0  # Nếu không đủ loss để tính, trả về 0

        variations = []
        for i in range(1, len(self.loss_history)):
            L_t = self.loss_history[i]
            L_t_minus_1 = self.loss_history[i - 1]
            # Tính độ biến thiên tương đối theo công thức
            delta_L = torch.abs(L_t - L_t_minus_1) / (L_t_minus_1 + 1e-8)  # Thêm epsilon để tránh chia cho 0
            variations.append(delta_L)

        # Trả về trung bình của các độ biến thiên
        return torch.mean(torch.stack(variations))
    def adjust_loss(self, current_loss):
        """
        Điều chỉnh loss hiện tại dựa trên độ biến thiên của các loss gần nhất.
        Args:
            current_loss (torch.Tensor): Giá trị loss hiện tại.
        Returns:
            torch.Tensor: Loss đã được điều chỉnh.
        """
        # Thêm loss hiện tại vào history
        self.loss_history.append(current_loss.detach())
        if len(self.loss_history) > self.history_size:
            self.loss_history.pop(0)

        # Tính độ biến thiên
        variation = self.compute_variation()

        # Điều chỉnh loss dựa trên độ biến thiên
        adjusted_loss = current_loss * (1 + self.lambda_smooth * variation)

        return adjusted_loss
    def moreau_envelope_smooth(self, current_loss):
        """Áp dụng Moreau Envelope để làm mịn loss."""
        # Thêm loss hiện tại vào history
        self.loss_history.append(current_loss.detach())
        if len(self.loss_history) > self.history_size:
            self.loss_history.pop(0)

        # Tính độ biến thiên
        variation = self.compute_variation()

        # Điều chỉnh lambda_smooth dựa trên độ biến thiên
        adaptive_lambda = self.lambda_smooth * (1 + variation)

        # Áp dụng Moreau Envelope
        if len(self.loss_history) > 0:
            loss_tensor = torch.stack(self.loss_history)
            # Tính trung bình có trọng số của các loss gần nhất
            weights = torch.exp(-torch.arange(len(loss_tensor), dtype=torch.float32) / adaptive_lambda)
            weights = weights / weights.sum()
            smoothed_loss = (current_loss + 
                           adaptive_lambda * torch.sum(weights * loss_tensor)) / (1 + adaptive_lambda)
        else:
            smoothed_loss = current_loss

        return smoothed_loss
class clientPerAvg(Client):
    def __init__(self, args, id, train_samples, test_samples, **kwargs):
        super().__init__(args, id, train_samples, test_samples, **kwargs)

        # self.beta = args.beta
        self.beta = self.learning_rate
        self.tau = args.tau
        self.mu = args.mu

        self.global_model = None
        self.old_model = copy.deepcopy(self.model)
        self.lamda = args.lamda
        self.K = args.K
        self.personalized_learning_rate = args.p_learning_rate
        self.beta = self.learning_rate
        self.optimizer = PerAvgOptimizer(self.model.parameters(), lr=self.learning_rate)
        self.learning_rate_scheduler = torch.optim.lr_scheduler.ExponentialLR(
            optimizer=self.optimizer, 
            gamma=args.learning_rate_decay_gamma
        )

    def train(self):
        trainloader = self.load_train_data(self.batch_size*2)
        start_time = time.time()
          # Chuẩn hóa dữ liệu về chuẩn 0 -> 1
       

    # Mã hóa nhãn
      
        # self.model.to(self.device)
        self.model.train()

        max_local_epochs = self.local_epochs
        if self.train_slow:
            max_local_epochs = np.random.randint(1, max_local_epochs // 2)
        for step in range(max_local_epochs):  # local update
            smooth_tracker = SmoothLossTracker(lambda_smooth=0.1, history_size=3)

            for X, Y in trainloader:
                temp_model = copy.deepcopy(list(self.model.parameters()))
               
                # step 1
                if type(X) == type([]):
                    x = [None, None]
                    x[0] = X[0][:self.batch_size].to(self.device)
                    x[1] = X[1][:self.batch_size]
                else:
                    x = X[:self.batch_size].to(self.device)
                y = Y[:self.batch_size].to(self.device)
                if self.train_slow:
                    time.sleep(0.1 * np.abs(np.random.rand()))
                rep = self.model.base(x)
                output = self.model.head(rep)
                loss = self.loss(output, y)

                rep_old = self.old_model.base(x).detach()
                rep_global = self.global_model.base(x).detach()
                loss_con = - torch.log(torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) / 
                    (torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) + torch.exp(F.cosine_similarity(rep, rep_old) / self.tau)))
                loss += self.mu * torch.mean(loss_con)
                loss = smooth_tracker.moreau_envelope_smooth(loss)
              #  print("print smooth_loss:")
              #  print(loss)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                # step 2
                if type(X) == type([]):
                    x = [None, None]
                    x[0] = X[0][self.batch_size:].to(self.device)
                    x[1] = X[1][self.batch_size:]
                else:
                    x = X[self.batch_size:].to(self.device)
                y = Y[self.batch_size:].to(self.device)
                if self.train_slow:
                    time.sleep(0.1 * np.abs(np.random.rand()))
                rep = self.model.base(x)
                output = self.model.head(rep)
                loss = self.loss(output, y)

                rep_old = self.old_model.base(x).detach()
                rep_global = self.global_model.base(x).detach()
                loss_con = - torch.log(torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) / (torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) + torch.exp(F.cosine_similarity(rep, rep_old) / self.tau)))
                loss += self.mu * torch.mean(loss_con)
                loss = smooth_tracker.moreau_envelope_smooth(loss)
              #  print("print smooth_loss:")
              #  print(loss)
                self.optimizer.zero_grad()
                loss.backward()

                # restore the model parameters to the one before first update
                for old_param, new_param in zip(self.model.parameters(), temp_model):
                    old_param.data = new_param.data.clone()

                self.optimizer.step(beta=self.beta)

        # self.model.cpu()
        self.old_model = copy.deepcopy(self.model)
        if self.learning_rate_decay:
            self.learning_rate_scheduler.step()

        self.train_time_cost['num_rounds'] += 1
        self.train_time_cost['total_cost'] += time.time() - start_time


    def train_one_step(self):
        trainloader = self.load_train_data(self.batch_size)
        iter_loader = iter(trainloader)
        # self.model.to(self.device)
        self.model.train()

        (x, y) = next(iter_loader)
        if type(x) == type([]):
            x[0] = x[0].to(self.device)
        else:
            x = x.to(self.device)
        y = y.to(self.device)
        output = self.model(x)
        loss = self.loss(output, y)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        # self.model.cpu()
    def evaluate_accuracy_per_label(self):
        testloader = self.load_test_data(self.batch_size)
        self.model.eval()

        correct = {}
        total = {}

        with torch.no_grad():
            for X, Y in testloader:
                
                if type(X) == type([]):
                    x = [None, None]
                    x[0] = X[0].to(self.device)
                    x[1] = X[1]
                else:
                    x = X.to(self.device)
                y = Y.to(self.device)
                outputs = self.model(x)
                _, predicted = torch.max(outputs.data, 1)

                for label in range(len(y)):
                    if label not in correct:
                        correct[label] = 0
                        total[label] = 0
                    total[label] += 1
                    correct[label] += (predicted == y[label]).sum().item()

        accuracies = {label: correct[label] / total[label] for label in correct}
        return accuracies
    def set_parameters(self, model):
        for new_param, old_param,  in zip(model.parameters(), self.model.parameters()):
            old_param.data = new_param.data.clone()
         #   local_param.data = new_param.data.clone()

        self.global_model = model
    def train_metrics(self, model=None):
        trainloader = self.load_train_data(self.batch_size*2)
        if model == None:
            model = self.model
        model.eval()

        train_num = 0
        losses = 0
        smooth_tracker = SmoothLossTracker(lambda_smooth=0.1, history_size=3)

        for X, Y in trainloader:
            # step 1
            
            if type(X) == type([]):
                x = [None, None]
                x[0] = X[0][:self.batch_size].to(self.device)
                x[1] = X[1][:self.batch_size]
            else:
                x = X[:self.batch_size].to(self.device)
            y = Y[:self.batch_size].to(self.device)
            if self.train_slow:
                time.sleep(0.1 * np.abs(np.random.rand()))
            self.optimizer.zero_grad()
            rep = self.model.base(x)
            output = self.model(x)
            loss = self.loss(output, y)
            rep_old = self.old_model.base(x).detach()
            rep_global = self.global_model.base(x).detach()
            loss_con = - torch.log(torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) / (torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) + torch.exp(F.cosine_similarity(rep, rep_old) / self.tau)))
            loss += self.mu * torch.mean(loss_con)
            loss.backward()
            self.optimizer.step()

            # step 2
            if type(X) == type([]):
                x = [None, None]
                x[0] = X[0][self.batch_size:].to(self.device)
                x[1] = X[1][self.batch_size:]
            else:
                x = X[self.batch_size:].to(self.device)
            y = Y[self.batch_size:].to(self.device)
            if self.train_slow:
                time.sleep(0.1 * np.abs(np.random.rand()))
            self.optimizer.zero_grad()
            output = self.model(x)
            rep = self.model.base(x)

            loss1 = self.loss(output, y)
            rep_old = self.old_model.base(x).detach()
            rep_global = self.global_model.base(x).detach()
            loss_con = - torch.log(torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) / (torch.exp(F.cosine_similarity(rep, rep_global) / self.tau) + torch.exp(F.cosine_similarity(rep, rep_old) / self.tau)))
            loss1 += self.mu * torch.mean(loss_con)
          #  loss = smooth_tracker.moreau_envelope_smooth(loss1)
          #  print("print smooth_loss:")
          #  print(loss)
            train_num += y.shape[0]
            losses += loss1.item() * y.shape[0]

        return losses, train_num

    def train_one_epoch(self):
        trainloader = self.load_train_data(self.batch_size)
        for i, (x, y) in enumerate(trainloader):
            if type(x) == type([]):
                x[0] = x[0].to(self.device)
            else:
                x = x.to(self.device)
            y = y.to(self.device)
            if self.train_slow:
                time.sleep(0.1 * np.abs(np.random.rand()))
            output = self.model(x)
            loss = self.loss(output, y)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()