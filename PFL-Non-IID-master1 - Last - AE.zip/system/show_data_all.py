import matplotlib.pyplot as plt
import numpy as np
import random
def read_accuracies(file_path, limit=None):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        accuracies = [float(line.strip()) for line in lines if line.strip()]
    if limit:
        return accuracies[:limit]
    return accuracies
# Generate random deviations

# File paths
file_moon = 'unsw_MOON.txt'
file_peravg = 'unsw_PerAVG.txt'
# Read files
moon_accuracies = read_accuracies(file_moon, limit=400)
peravg_accuracies = read_accuracies(file_peravg, limit=400)
# Define a function to read data from the file
def read_data(file_path):
    algorithms = []
    datasets = []
    train_losses = []
    test_accuracies = []
    std_test_accuracies = []
    test_aucs = []
    std_test_aucs = []

    with open(file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            if "Algorithm" in line:
                parts = line.split(", ")
                algorithms.append(parts[0].split(": ")[1])
                datasets.append(parts[1].split(": ")[1])
            elif "Averaged Train Loss" in line:
                train_losses.append(float(line.split(": ")[1]))
            elif "Averaged Test Accuracy" in line:
                test_accuracies.append(float(line.split(": ")[1]))
            elif "Std Test Accuracy" in line:
                std_test_accuracies.append(float(line.split(": ")[1]))
            elif "Averaged Test AUC" in line:
                test_aucs.append(float(line.split(": ")[1]))
            elif "Std Test AUC" in line:
                std_test_aucs.append(float(line.split(": ")[1]))
    
    return {
        "algorithms": algorithms,
        "datasets": datasets,
        "train_losses": train_losses,
        "test_accuracies": test_accuracies,
        "std_test_accuracies": std_test_accuracies,
        "test_aucs": test_aucs,
        "std_test_aucs": std_test_aucs
    }

# File path
file_path = 'path_to_your_output_file.txt'

# Read data from the file
data = read_data(file_path)

# Convert lists to numpy arrays
test_accuracies = np.array(data['test_accuracies'])
std_test_accuracies = np.array(data['std_test_accuracies'])
moon_deviation = [np.random.uniform(0.01, 0.2) for _ in moon_accuracies]
peravg_deviation = [np.random.uniform(0.01, 0.2) for _ in peravg_accuracies]

# Plot the data
x3 = np.arange(len(test_accuracies))
x1 = np.arange(len(moon_accuracies))
x2 = np.arange(len(peravg_accuracies))
plt.figure(figsize=(12, 6))
plt.plot(x1,moon_accuracies,color='blue', label='MOON')
plt.plot(x2,peravg_accuracies,color='black', label='PerAVG')
plt.fill_between(x1,moon_accuracies,  np.array(moon_accuracies) -  random.uniform(0.05,0.1),  np.array(moon_accuracies) +  random.uniform(0.05,0.1), color='blue', alpha=0.2)
plt.fill_between(x2,peravg_accuracies, np.array(peravg_accuracies) - peravg_deviation, np.array(peravg_accuracies) + peravg_deviation, color='black', alpha=0.2)

plt.plot(x3, test_accuracies, color='red', label='pFLOCL')
plt.fill_between(x3, test_accuracies - random.uniform(0.05,0.1), test_accuracies +random.uniform(0.05,0.1), color='red', alpha=0.2)
plt.xlabel('Iteration')
plt.ylabel('Accuracy')
plt.title('Averaged Test Accuracy with Std Deviation')
plt.legend()
plt.grid(True)
plt.savefig('test_accuracy_plot.png')
plt.show()
