import matplotlib.pyplot as plt
import numpy as np
import os

# Function to parse a file and extract overall accuracies
def parse_file(file_path):
    overall_accuracies = []
    with open(file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            if "Overall accuracy" in line:
                parts = line.strip().split(': ')
                overall_accuracy = float(parts[1])
                overall_accuracies.append(overall_accuracy)
    return overall_accuracies

# Directory where the files are located
directory = ''

# List of all file names
file_names = [
    'test_metrics_result_client0.txt', 'test_metrics_result_client1.txt', 
    'test_metrics_result_client2.txt', 'test_metrics_result_client3.txt', 
    'test_metrics_result_client4.txt', 'test_metrics_result_client5.txt', 
    'test_metrics_result_client6.txt', 'test_metrics_result_client7.txt', 
    'test_metrics_result_client8.txt', 'test_metrics_result_client9.txt', 
    'test_metrics_result_client10.txt', 'test_metrics_result_client11.txt', 
    'test_metrics_result_client12.txt', 'test_metrics_result_client13.txt', 
    'test_metrics_result_client14.txt', 'test_metrics_result_client15.txt', 
    'test_metrics_result_client16.txt', 'test_metrics_result_client17.txt', 
    'test_metrics_result_client18.txt', 'test_metrics_result_client19.txt'
]

# Parse each file and gather overall accuracies
all_overall_accuracies = []
for file_name in file_names:
    file_path = os.path.join(directory, file_name)
    overall_accuracies = parse_file(file_path)
    all_overall_accuracies.append(overall_accuracies)

# Ensure that all sequences have the same length by padding with NaN values
max_length = max(len(acc) for acc in all_overall_accuracies)
padded_overall_accuracies = [acc + [np.nan] * (max_length - len(acc)) for acc in all_overall_accuracies]

# Convert overall accuracies to numpy array for easier manipulation
all_overall_accuracies_np = np.array(padded_overall_accuracies)

# Calculate the average, max, min, and std overall accuracy per dataset index across all clients
average_overall_accuracies = np.nanmean(all_overall_accuracies_np, axis=0)
std_overall_accuracies = np.nanstd(all_overall_accuracies_np, axis=0)
max_overall_accuracies = np.nanmax(all_overall_accuracies_np, axis=0)
min_overall_accuracies = np.nanmin(all_overall_accuracies_np, axis=0)

# Create a 2D plot
fig, ax = plt.subplots(figsize=(14, 8))

# Dataset indices
dataset_indices = np.arange(max_length)

# Plot average overall accuracy with shaded area for std deviation
ax.plot(dataset_indices, average_overall_accuracies, label='Average Overall Accuracy', linestyle='-', linewidth=2, color='blue')
ax.fill_between(dataset_indices, average_overall_accuracies - std_overall_accuracies, average_overall_accuracies + std_overall_accuracies, color='blue', alpha=0.2)

# Plot individual client overall accuracies
for i, client_accuracies in enumerate(all_overall_accuracies_np):
    ax.plot(dataset_indices, client_accuracies, linestyle='-', linewidth=1, alpha=0.5, color='gray')

# Plot control limits for overall accuracy
ax.plot(dataset_indices, max_overall_accuracies, label='Upper Control Limit (UCL)', linestyle='--', linewidth=2, color='red')
ax.plot(dataset_indices, min_overall_accuracies, label='Lower Control Limit (LCL)', linestyle='--', linewidth=2, color='green')

# Adding title and labels
ax.set_title('Control Chart for Overall Accuracy per Dataset Index for Each Client')
ax.set_xlabel('Dataset Index')
ax.set_ylabel('Accuracy')
ax.legend()

plt.show()
