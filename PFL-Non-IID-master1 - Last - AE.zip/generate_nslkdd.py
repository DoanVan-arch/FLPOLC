import os
import sys
import pandas as pd
import numpy as np
import random
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from utils.dataset_utils import check, separate_data, split_data, save_file

pd.options.mode.chained_assignment = None  # default='warn'
# fileDir = os.path.dirname(os.path.abspath("__file__"))
import pdb

random.seed(1)
np.random.seed(1)
data_path = "nslkdd/"
dir_path = "nslkdd/"
num_clients = 20
num_classes = 5


def read_nsl_kdd(fileDir):
    train_data, test_data = [], []

    pathTrain = os.path.join(fileDir, "raw/NSLKDD_Train.csv")
    pathTest = os.path.join(fileDir, "raw/NSLKDD_Test.csv")

    TrainData = np.genfromtxt(pathTrain, delimiter=",")
    TestData = np.genfromtxt(pathTest, delimiter=",")

    print("train size", TrainData.shape)
    print("test size", TestData.shape)

    y_train = TrainData[:, -1]
    y_test = TestData[:, -1]

    # y_train[y_train != 0] = 1
    # y_test[y_test != 0] = 1

    X_train = TrainData[:, 0:-1]
    X_test = TestData[:, 0:-1]

    X_train = np.array(X_train, dtype=np.float64)
    X_test = np.array(X_test, dtype=np.float64)
    y_train = np.array(y_train, dtype=np.float64)
    y_test = np.array(y_test, dtype=np.float64)

    mmsc = MinMaxScaler()
    X_train = mmsc.fit_transform(X_train)
    X_test = mmsc.transform(X_test)
    # pdb.set_trace()

    train_data.append({'x': X_train, 'y': y_train})
    test_data.append({'x': X_test, 'y': y_test})

    return train_data, test_data



# Allocate data to users
def generate_nslkdd(dir_path, num_clients, num_classes, niid, balance, partition):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        
    # Setup directory for train/test data
    config_path = dir_path + "config.json"
    train_path = dir_path + "train/"
    test_path = dir_path + "test/"

    if not os.path.exists(train_path):
        os.makedirs(train_path)
    if not os.path.exists(test_path):
        os.makedirs(test_path)

    train_data, test_data = read_nsl_kdd (data_path)
    # pdb.set_trace()
    x = np.concatenate ([train_data [0] ['x'], test_data [0] ['x']], axis = 0)
    y = np.concatenate ([train_data [0] ['y'], test_data [0] ['y']], axis = 0)


    X, y, statistic = separate_data((x,y), num_clients, num_classes, 
                                    niid, balance, partition)
    train_data, test_data = split_data(X, y)
    save_file(config_path, train_path, test_path, train_data, test_data, num_clients, num_classes, 
        statistic, niid, balance, partition)



if __name__ == "__main__":
    niid = True if sys.argv[1] == "noniid" else False
    balance = True if sys.argv[2] == "balance" else False
    partition = sys.argv[3] if sys.argv[3] != "-" else None


    generate_nslkdd(dir_path, num_clients, num_classes, niid, balance, partition)